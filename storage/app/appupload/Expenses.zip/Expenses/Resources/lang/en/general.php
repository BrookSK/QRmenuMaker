<?php

return [

    'name'              => 'Expenses',
    'description'       => 'This is my awesome module',

];