<?php

return [
    'name' => 'Expenses'
];
