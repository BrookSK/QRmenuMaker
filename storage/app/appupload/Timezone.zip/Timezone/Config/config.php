<?php

return [
    'name' => 'Timezone'
];
