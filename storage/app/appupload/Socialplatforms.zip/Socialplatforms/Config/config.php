<?php

return [
    'name' => 'Socialplatforms'
];
