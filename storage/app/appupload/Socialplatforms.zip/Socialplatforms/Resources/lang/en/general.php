<?php

return [

    'name'              => 'Socialplatforms',
    'description'       => 'This is my awesome module',

];