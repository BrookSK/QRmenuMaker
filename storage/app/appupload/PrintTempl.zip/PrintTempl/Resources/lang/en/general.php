<?php

return [

    'name'              => 'PrintTempl',
    'description'       => 'This is my awesome module',

];