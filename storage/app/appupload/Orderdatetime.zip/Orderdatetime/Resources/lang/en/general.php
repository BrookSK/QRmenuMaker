<?php

return [

    'name'              => 'Orderdatetime',
    'description'       => 'This is my awesome module',

];