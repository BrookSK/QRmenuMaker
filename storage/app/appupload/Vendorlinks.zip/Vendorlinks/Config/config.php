<?php

return [
    'name' => 'Vendorlinks',
    'enable'=>env('ENABLE_VENDOR_LINKS',false),
    'name'=>env('NAME_OF_THE_MENU_IN_VENDOR_LINKS','Support'),
    'link1name'=>env('LINK_ONE_NAME',''),
    'link2name'=>env('LINK_TWO_NAME',''),
    'link3name'=>env('LINK_THREE_NAME',''),
    'link1link'=>env('LINK_ONE_LINK',''),
    'link2link'=>env('LINK_TWO_LINK',''),
    'link3link'=>env('LINK_THREE_LINK',''),
  
];
