<?php

return [

    'name'              => 'Tips',
    'description'       => 'This is my awesome module',

];