<?php

return [
    'name' => 'Tips'
];
