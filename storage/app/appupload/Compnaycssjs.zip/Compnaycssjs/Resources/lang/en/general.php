<?php

return [

    'name'              => 'Compnaycssjs',
    'description'       => 'This is my awesome module',

];