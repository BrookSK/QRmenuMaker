<?php

return [

    'name'              => 'Paypal',
    'description'       => 'This is my awesome module',

];