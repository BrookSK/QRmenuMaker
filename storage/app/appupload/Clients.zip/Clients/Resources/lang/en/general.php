<?php

return [

    'name'              => 'Clients',
    'description'       => 'This is my awesome module',

];