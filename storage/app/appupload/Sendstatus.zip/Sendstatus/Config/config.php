<?php

return [
    'name' => 'Sendstatus'
];
