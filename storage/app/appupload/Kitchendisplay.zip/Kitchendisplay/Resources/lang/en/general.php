<?php

return [

    'name'              => 'Kitchendisplay',
    'description'       => 'This is my awesome module',

];