@extends('kitchendisplay::layouts.master')


@section('orders')
  @include('kitchendisplay::orders')
@endsection





