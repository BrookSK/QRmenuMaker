<?php

return [

    'name'              => 'Drivers',
    'description'       => 'This is my awesome module',

];