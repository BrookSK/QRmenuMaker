<?php

return [

    'name'              => 'Timprepare',
    'description'       => 'This is my awesome module',

];