<?php

return [

    'name'              => 'Allergens',
    'description'       => 'This is my awesome module',

];