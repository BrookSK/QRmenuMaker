<?php

return [
    'name' => 'Allergens'
];
