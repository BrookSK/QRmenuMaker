<?php

return [

    'name'              => 'Floorplan',
    'description'       => 'This is my awesome module',

];