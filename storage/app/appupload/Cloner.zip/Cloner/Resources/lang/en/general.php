<?php

return [

    'name'              => 'Cloner',
    'description'       => 'This is my awesome module',

];