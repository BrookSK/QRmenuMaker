<?php

return [

    'name'              => 'Stock',
    'description'       => 'This is my awesome module',

];