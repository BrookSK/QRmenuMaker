<?php

return [
    'name' => 'Stock'
];
