<?php

return [
    'name' => 'Domain'
];
