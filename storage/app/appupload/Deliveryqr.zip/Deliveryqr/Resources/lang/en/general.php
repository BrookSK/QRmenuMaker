<?php

return [

    'name'              => 'Deliveryqr',
    'description'       => 'This is my awesome module',

];